library bot_test;

import 'dart:async';
import 'package:unittest/unittest.dart';
import 'package:bot/bot.dart';

part 'src/bot_test/event_watcher.dart';
part 'src/bot_test/top_level.dart';
