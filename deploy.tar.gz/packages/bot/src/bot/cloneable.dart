part of bot;

abstract class Cloneable<T> {
  T clone();
}
